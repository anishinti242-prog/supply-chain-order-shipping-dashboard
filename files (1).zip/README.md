# End-to-End Supply Chain Analysis Project

Interactive dashboard showing which orders have shipped and which have not, with order value at $300 per order.

## Files
- `index.html` – the dashboard (single file, no dependencies)
- `Order_Shipping_Status.xlsx` – underlying data and summary tables

## View it online (GitHub Pages)
1. Upload these files to your repository.
2. Go to **Settings → Pages**, choose **Deploy from a branch**, select `main` and `/ (root)`, then **Save**.
3. Your dashboard appears at `https://YOUR-USERNAME.github.io/REPO-NAME/`.

## Method
- Duplicate listings merged by order number (142 unique orders).
- Shipped = remark says shipped, or live status is in transit / delivered.
- Order value is a fixed $300 assumption.

## Tools Used
- HTML, CSS, JavaScript (interactive dashboard)
- Python: pandas, openpyxl (data processing)
- Microsoft Excel (reporting)
- GitHub Pages (hosting)
- Claude AI by Anthropic (development assistance)
